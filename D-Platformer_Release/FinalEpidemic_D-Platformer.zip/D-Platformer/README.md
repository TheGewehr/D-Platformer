# GAME DEV PLATFORMER: D-Platformer

## Welcome to Flea World

Final Epidemic is a group of two students coursing the second year Bachelor's degree in Video Game Design and Development at UPC university. The integrants of the group are Alexandre Carreras and Carlos Arnau.

GitHub project link: https://github.com/IconicGIT/FinalPandemic

<p>&nbsp;</p>

## TEAM MEMBERS

- **Carlos Arnau** [[ _carlosarnau_ ](https://github.com/carlosarnau)]

- **Alexandre Carreras** [[ _TheGewehr_ ](https://github.com/TheGewehr)]

<p>&nbsp;</p>

## GAME CONTROLS
~~~~~~~~~~~~~~~

Keyboard Player controls:

- JUMP --> SPACE key
- LEFT --> A key
- RIGHT --> D key
- SLOW MOTION HABILITY --> Q key

General controls:

- EXIT GAME --> ESC key
- RESTART GAME --> F3 key

Debug Controls:
- SAVE GAME --> F5 key
- LOAD GAME --> F6 key
- LEVEL 1 --> F1 key
- DEBUG MODE --> F9 key
- CHANGE FPS --> F11 key

~~~~~~~~~~~~~~~

<p>&nbsp;</p>

## DEV Diary

We got a lot of problems creating the first version of our game. 
So that made us restart the project and redo everythng we already
had but this time with the Box2D library. This task was relatively
simple but time consuming, forcing the team to work much more for
this version of the game that the previous one. 
The result is the expected, time control and pathfinder enemies
that make richer the playable level of the game. Each of them
the features has been thinked twice so the playablilty is the
expected. The player will have a bad time not being killed
by the enemies while it jumps throught the level to get to 
the win point.

## Future of the team

Unfortunatly Final Epidemic will be diluded beacose of 
developpement problems due to organization. Once this release
is published, each of the team members will persue his own 
project. This one will be entirely owned by TheGewehr AKA TheVeteran
and another one will be created in the _carlosarnau_ account

Don't be sad, it is a change for the good of both of us

## Final Note

Stay updated on our projects, we will be releasing the final version
of our respective projects before the 1rst of february 2022, see you then 
and enjoy this release ;-)
